#include <iostream>
using namespace std;

int main() {
    cout << "Prva rechenica.\n";
    cout << "Vtora rechenica.\nTreta rechenica.";
    return 0;
}
