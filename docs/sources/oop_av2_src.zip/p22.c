#include <stdio.h>

int main() {
    int x = 7;
    printf("Brojot %d na kvadrat e %d\n", x, x * x);
    return 0;
}
