#include <iostream>
using namespace std;

// glavna funkcija
int main() {
    /*
    pechatenje poraka na ekran
    */
    cout << "Dobredojdovte na FINKI!" << endl;
    return 0;
}
