#include <stdio.h>

int main() {
    printf(" e zbor dolg %d bukvi.\n", printf("Makedonija"));
    return 0;
}
