#include <stdio.h>

int main() {
    int x, y, z;
    z = scanf("%d%d", &x, &y);
    printf("z = %d\n", z);
    return 0;
}
