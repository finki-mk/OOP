#include <stdio.h>

// main function
int main() {
    /*
    Printing a message on the standard output (the screen)
    */
    printf("Welcome to FINKI!\n");
    return 0;
}
