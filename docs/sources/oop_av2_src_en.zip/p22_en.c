#include <stdio.h>

int main() {
    int x = 7;
    printf("Number %d squared is %d\n", x, x * x);
    return 0;
}
