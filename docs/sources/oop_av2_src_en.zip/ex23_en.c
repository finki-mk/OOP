#include <stdio.h>

int main() {
    const long double PI = 3.141592653590L;
    const int DAYS_IN_WEEK = 7;
    const SUNDAY = 0; // by default int
    DAYS_IN_WEEK = 7; // error
    return 0;
}
