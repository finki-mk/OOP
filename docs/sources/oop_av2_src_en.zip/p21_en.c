#include <stdio.h>

int main() {
    float x = 3.0 / 2 + (5 - 46 * 5.0 / 12);
    printf("x = %.2f\n", x);
    return 0;
}
